package TP4;

class NegatifException extends Exception{

    
}

