package Session2;


/**
 * Décrivez votre classe CommandeException ici.
 *
 * @author (votre nom)
 * @version (un numéro de version ou une date)
 */
public class CommandeException extends Exception
{
    
    public CommandeException()
    {
    }
}
