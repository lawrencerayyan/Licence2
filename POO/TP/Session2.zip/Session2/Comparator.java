package Session2;



/**
 * Décrivez votre classe Comparaison ici.
 *
 * @author (votre nom)
 * @version (un numéro de version ou une date)
 */
public interface Comparator
{
    public boolean compare ( Produit a , Produit b ) ;
}
