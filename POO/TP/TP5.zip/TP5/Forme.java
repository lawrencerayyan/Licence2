package TP5;


/**
 * Décrivez votre classe Forme ici.
 *
 * @author (votre nom)
 * @version (un numéro de version ou une date)
 */
public class Forme
{
    // variables d'instance - remplacez l'exemple qui suit par le vôtre
    Point [] tab; 
    private int x;

    
    public Forme()
    {
        // initialisation des variables d'instance
        
    }

    
}
