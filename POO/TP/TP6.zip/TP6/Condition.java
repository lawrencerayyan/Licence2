package TP6;

public interface Condition {
    boolean verif(int param);
}
