package TP6;

public class Vegetable {

}
