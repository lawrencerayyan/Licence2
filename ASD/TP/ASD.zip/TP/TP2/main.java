package TP2;



public class main
{
   

    public static void main(String[] args)
    {
        // System.out.println(exo1.somme_recusif(4));
        // System.out.println(exo1.somme_recusif_bis(4,0));
        exo2.Fibonacci(10);
    }

   
}
