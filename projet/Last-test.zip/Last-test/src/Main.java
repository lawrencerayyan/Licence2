package src;

public class Main {
    
    public static void main( String[] args ){
        
        Graphique game = new Graphique(new Board());
        game.run();
    }
}
